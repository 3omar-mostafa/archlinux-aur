<?xml version="1.0" ?><!DOCTYPE TS><TS language="en_GB" version="2.1">
<context>
    <name>AboutDialog</name>
    <message>
        <source>License</source>
        <translation>Licence</translation>
    </message>
</context>
<context>
    <name>XmlNode</name>
    <message>
        <source>Color</source>
        <translation>Colour</translation>
    </message>
</context>
</TS>
