## Notice

To improve the crowdsourcing experience for non-developers, this project is translated
on [Transiflex](https://www.transifex.com/qwertycube/apk-editor-studio/).
Please follow the [translation instructions](https://github.com/kefir500/apk-editor-studio/wiki/Translation-Guide)
and avoid direct editing of the language files in this repo.
